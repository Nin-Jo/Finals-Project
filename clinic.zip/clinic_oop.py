from typing import Optional

#OWNER CLASS + tuple form + entry validation
class Owner:
    def __init__(self, owner_id: Optional[int] = None, owner_name: str = "",
                 owner_phone: Optional[str] = None, owner_email: Optional[str] = None):
        self.owner_id, self.owner_name, self.owner_phone, self.owner_email = owner_id, owner_name, owner_phone, owner_email

    def as_tuple(self):
        return (self.owner_name, self.owner_phone, self.owner_email)

    def validate(self):
        if not self.owner_name:
            return False, "Owner name is required."
        return True, ""

#VET CLASS + tuple form + entry validation
class Vet:
    def __init__(self, vet_id: Optional[int] = None, vet_name: str = "",
                 vet_phone: Optional[str] = None, vet_email: Optional[str] = None, specialty: Optional[str] = None):
        self.vet_id, self.vet_name, self.vet_phone, self.vet_email, self.specialty = vet_id, vet_name, vet_phone, vet_email, specialty

    def as_tuple(self):
        return (self.vet_name, self.vet_phone, self.vet_email, self.specialty)

    def validate(self):
        if not self.vet_name:
            return False, "Vet name is required."
        return True, ""

#APPOINTMENT CLASS + tuple form + entry validation
class Appointment:
    def __init__(self, id: Optional[int] = None, appt: str = "", appt_type: str = "",
                 pet_type: Optional[str] = None, gender: Optional[str] = None, name: Optional[str] = None, breed: Optional[str] = None,
                 age_yrs: Optional[float] = None, weight_kgs: Optional[float] = None, color: Optional[str] = None,
                owner: Optional[Owner] = None, vet: Optional[Vet] = None, price: Optional[float] = None):
        self.id = id
        self.appt = appt
        self.appt_type = appt_type
        self.pet_type = pet_type
        self.gender = gender
        self.name = name
        self.breed = breed
        self.age_yrs = age_yrs
        self.weight_kgs = weight_kgs
        self.color = color
        self.owner = owner
        self.vet = vet
        self.price = price

    def as_tuple(self):
        owner_name = self.owner.owner_name if self.owner else None
        vet_name = self.vet.vet_name if self.vet else None
        return (self.appt, self.appt_type, self.pet_type, self.gender, self.name, self.breed, self.age_yrs, self.weight_kgs, self.color,
                owner_name, vet_name, self.price)

    def validate(self):
        if not self.appt:
            return False, "Appointment date and time is required."

        if not self.appt_type:
            return False, "Appointment type is required."

        if self.owner is None:
            return False, "Owner is missing."

        is_owner_valid, owner_msg = self.owner.validate()
        if not is_owner_valid:
            return False, f"Owner error: {owner_msg}"

        if self.vet is None:
            return False, "Vet is missing."

        is_vet_valid, vet_msg = self.vet.validate()
        if not is_vet_valid:
            return False, f"Vet error: {vet_msg}"

        return True, ""
