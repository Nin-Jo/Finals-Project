import sys
from PyQt5.QtWidgets import QApplication
from clinic_crud import Database
from clinic_ui import ClinicApp

app = QApplication(sys.argv)
db = Database()
window = ClinicApp(db)
window.show()
sys.exit(app.exec_())