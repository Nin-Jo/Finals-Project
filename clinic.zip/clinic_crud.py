import sqlite3
from clinic_oop import Owner, Vet, Appointment

class Database:
    def __init__(self, data="clinic.sqlite3"):
        self.conn = sqlite3.connect(data)
        self.cursor = self.conn.cursor()

#OWNERS CRUD + (abandoned: search by name pattern)
    def create_owner(self, owner: Owner):
        self.cursor.execute("INSERT INTO owners (owner_name, owner_phone, owner_email) VALUES (?, ?, ?)",
                                owner.as_tuple())
        self.conn.commit()

    def read_owner(self):
        self.cursor.execute("SELECT * FROM owners")
        rows = self.cursor.fetchall()
        return [Owner(*row) for row in rows]

    def update_owner(self, owner: Owner):
        self.cursor.execute("UPDATE owners SET owner_name=?, owner_phone=?, owner_email=? WHERE owner_id=?",
                            (owner.owner_name, owner.owner_phone, owner.owner_email, owner.owner_id))
        self.conn.commit()

    def delete_owner(self, owner_id):
        self.cursor.execute("DELETE FROM owners WHERE owner_id=?", (owner_id,))
        self.conn.commit()

    # def search_owners(self, name_substring=""):
    #     self.cursor.execute("SELECT * FROM owners WHERE owner_name LIKE ?", ('%' + name_substring + '%',))
    #     rows = self.cursor.fetchall()
    #     return [Owner(*row) for row in rows]

#VETS CRUD + (abandoned: search by name pattern and/or specialty)
    def create_vet(self, vet: Vet):
        self.cursor.execute("INSERT INTO vets (vet_name, vet_phone, vet_email, specialty) VALUES (?, ?, ?, ?)",
                                vet.as_tuple())
        self.conn.commit()

    def read_vet(self):
        self.cursor.execute("SELECT * FROM vets")
        rows = self.cursor.fetchall()
        return [Vet(*row) for row in rows]

    def update_vet(self, vet: Vet):
        self.cursor.execute("UPDATE vets SET vet_name=?, vet_phone=?, vet_email=?, specialty=? WHERE vet_id=?",
                                (vet.vet_name, vet.vet_phone, vet.vet_email, vet.specialty, vet.vet_id))
        self.conn.commit()

    def delete_vet(self, vet_id):
        self.cursor.execute("DELETE FROM vets WHERE vet_id=?", (vet_id,))
        self.conn.commit()


    # def search_vets(self, name_substring="", specialty=None):
    #     base_query = "SELECT * FROM vets"
    #     filters = []
    #     params = []
    #
    #     if name_substring:
    #         filters.append("vet_name LIKE ?")
    #         params.append(f"%{name_substring}%")
    #
    #     if specialty:
    #         filters.append("specialty = ?")
    #         params.append(specialty)
    #
    #     if filters:
    #         full_query = f"{base_query} WHERE {' AND '.join(filters)}"
    #     else:
    #         full_query = base_query
    #
    #     self.cursor.execute(full_query, params)
    #     rows = self.cursor.fetchall()
    #     return [Vet(*row) for row in rows]

#APPOINTMENTS CRUD + (abandoned: search by date pattern and/or owner/vet name pattern)
    def create_appointment(self, appointment: Appointment):
        self.cursor.execute("""INSERT INTO appointments (appt, appt_type, pet_type, gender, name, breed, 
                                                                age_yrs, weight_kgs, color, owner, vet, price) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                                    appointment.as_tuple())
        self.conn.commit()

    def read_appointment(self):
        self.cursor.execute("SELECT * FROM appointments")
        rows = self.cursor.fetchall()
        return [Appointment(*row) for row in rows]

    def update_appointment(self, appointment: Appointment):
        self.cursor.execute("""UPDATE appointments SET appt=?, appt_type=?, pet_type=?, gender=?, name=?, breed=?,
                                                            age_yrs=?, weight_kgs=?, color=?, owner=?, vet=?, price=? 
                                    WHERE id=?""",
                            (appointment.appt, appointment.appt_type, appointment.pet_type, appointment.gender,
                                        appointment.name, appointment.breed, appointment.age_yrs, appointment.weight_kgs,
                                        appointment.color,
                                        appointment.owner.owner_name if appointment.owner else None,
                                        appointment.vet.vet_name if appointment.vet else None,
                                        appointment.price, appointment.id))
        self.conn.commit()

    def delete_appointment(self, id):
        self.cursor.execute("DELETE FROM appointments WHERE id=?", (id,))
        self.conn.commit()

    # def search_appointments(self, appt_substring="", owner_name_substring="", vet_name_substring=""):
    #     query = "SELECT * FROM appointments"
    #     filters = []
    #     params = []
    #
    #     if appt_substring:
    #         filters.append("appt LIKE ?")
    #         params.append(f"%{appt_substring}%")
    #
    #     if owner_name_substring:
    #         filters.append("owner LIKE ?")
    #         params.append(f"%{owner_name_substring}%")
    #
    #     if vet_name_substring:
    #         filters.append("vet LIKE ?")
    #         params.append(f"%{vet_name_substring}%")
    #
    #     if filters:
    #         query += " WHERE " + " AND ".join(filters)
    #
    #     self.cursor.execute(query, params)
    #     rows = self.cursor.fetchall()
    #     return [Appointment(*row) for row in rows]
