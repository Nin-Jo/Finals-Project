from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,
                             QPushButton, QTableWidget, QTableWidgetItem, QTabWidget)

class ClinicApp(QMainWindow):
    def __init__(self, db):
        super().__init__()
        self.setWindowTitle("Vet Clinic Management")
        self.setGeometry(100, 100, 900, 600)

        self.db = db
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout()
        central_widget.setLayout(layout)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.init_owners_tab()
        self.init_vets_tab()
        self.init_appointments_tab()

#OWNERS TAB UI -------------------------------------------------------------
    def init_owners_tab(self):
        tab = QWidget()
        vbox = QVBoxLayout()
        tab.setLayout(vbox)

        #Owners table
        self.owner_table = QTableWidget()
        vbox.addWidget(self.owner_table)
        self.owner_table.setEditTriggers(QTableWidget.NoEditTriggers)

        #Input fields for name, phone, email
        form_layout = QHBoxLayout()
        self.owner_name_input = QLineEdit()
        self.owner_name_input.setPlaceholderText("Owner Name")
        self.owner_phone_input = QLineEdit()
        self.owner_phone_input.setPlaceholderText("Phone")
        self.owner_email_input = QLineEdit()
        self.owner_email_input.setPlaceholderText("Email")

        form_layout.addWidget(self.owner_name_input)
        form_layout.addWidget(self.owner_phone_input)
        form_layout.addWidget(self.owner_email_input)
        vbox.addLayout(form_layout)

        #Buttons
        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_owners)

        add_btn = QPushButton("Add Owner")
        add_btn.clicked.connect(self.add_owner)

        edit_btn = QPushButton("Edit Selected")
        edit_btn.clicked.connect(self.edit_owner)

        delete_btn = QPushButton("Delete Selected")
        delete_btn.clicked.connect(self.delete_owner)

        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(delete_btn)
        vbox.addLayout(btn_layout)

        #Owners table tab
        self.tabs.addTab(tab, "Owners")
        self.load_owners()

    #Display
    def load_owners(self):
        owners = self.db.read_owner()
        self.owner_table.setRowCount(len(owners))
        self.owner_table.setColumnCount(4)
        self.owner_table.setHorizontalHeaderLabels(["ID", "Name", "Phone", "Email"])
        for row_idx, owner in enumerate(owners):
            self.owner_table.setItem(row_idx, 0, QTableWidgetItem(str(owner.owner_id)))
            self.owner_table.setItem(row_idx, 1, QTableWidgetItem(owner.owner_name))
            self.owner_table.setItem(row_idx, 2, QTableWidgetItem(owner.owner_phone or ""))
            self.owner_table.setItem(row_idx, 3, QTableWidgetItem(owner.owner_email or ""))

    #Owners tab CRUD
    def add_owner(self):
        name = self.owner_name_input.text().strip()
        phone = self.owner_phone_input.text().strip()
        email = self.owner_email_input.text().strip()

        if not name:
            print("Owner name is required.")
            return

        from clinic_oop import Owner
        new_owner = Owner(owner_name=name, owner_phone=phone, owner_email=email)
        self.db.create_owner(new_owner)
        self.load_owners()

    def edit_owner(self):
        selected_row = self.owner_table.currentRow()
        if selected_row == -1:
            print("Select a row to edit.")
            return

        owner_id = int(self.owner_table.item(selected_row, 0).text())
        name = self.owner_name_input.text().strip() or self.owner_table.item(selected_row, 1).text()
        phone = self.owner_phone_input.text().strip() or self.owner_table.item(selected_row, 2).text()
        email = self.owner_email_input.text().strip() or self.owner_table.item(selected_row, 3).text()

        from clinic_oop import Owner
        updated_owner = Owner(owner_id, name, phone, email)
        self.db.update_owner(updated_owner)
        self.load_owners()

    def delete_owner(self):
        selected_row = self.owner_table.currentRow()
        if selected_row == -1:
            print("Select a row to delete.")
            return

        owner_id = int(self.owner_table.item(selected_row, 0).text())
        self.db.delete_owner(owner_id)
        self.load_owners()

#VETS TAB UI -------------------------------------------------------------
    def init_vets_tab(self):
        tab = QWidget()
        vbox = QVBoxLayout()
        tab.setLayout(vbox)

        #Vets table
        self.vet_table = QTableWidget()
        vbox.addWidget(self.vet_table)
        self.vet_table.setEditTriggers(QTableWidget.NoEditTriggers)

        #Input fields for name, phone, email, specialty
        form_layout = QHBoxLayout()
        self.vet_name_input = QLineEdit()
        self.vet_name_input.setPlaceholderText("Vet Name")
        self.vet_phone_input = QLineEdit()
        self.vet_phone_input.setPlaceholderText("Phone")
        self.vet_email_input = QLineEdit()
        self.vet_email_input.setPlaceholderText("Email")
        self.vet_specialty_input = QLineEdit()
        self.vet_specialty_input.setPlaceholderText("Specialty")

        form_layout.addWidget(self.vet_name_input)
        form_layout.addWidget(self.vet_phone_input)
        form_layout.addWidget(self.vet_email_input)
        form_layout.addWidget(self.vet_specialty_input)
        vbox.addLayout(form_layout)

        #Buttons
        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_vets)

        add_btn = QPushButton("Add Vet")
        add_btn.clicked.connect(self.add_vet)

        edit_btn = QPushButton("Edit Selected")
        edit_btn.clicked.connect(self.edit_vet)

        delete_btn = QPushButton("Delete Selected")
        delete_btn.clicked.connect(self.delete_vet)

        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(delete_btn)
        vbox.addLayout(btn_layout)

        #Vets table tab
        self.tabs.addTab(tab, "Vets")
        self.load_vets()

    #Display
    def load_vets(self):
        vets = self.db.read_vet()
        self.vet_table.setRowCount(len(vets))
        self.vet_table.setColumnCount(5)
        self.vet_table.setHorizontalHeaderLabels(["ID", "Name", "Phone", "Email", "Specialty"])
        for row_idx, vet in enumerate(vets):
            self.vet_table.setItem(row_idx, 0, QTableWidgetItem(str(vet.vet_id)))
            self.vet_table.setItem(row_idx, 1, QTableWidgetItem(vet.vet_name))
            self.vet_table.setItem(row_idx, 2, QTableWidgetItem(vet.vet_phone or ""))
            self.vet_table.setItem(row_idx, 3, QTableWidgetItem(vet.vet_email or ""))
            self.vet_table.setItem(row_idx, 4, QTableWidgetItem(vet.specialty or ""))

    #Vets tab CRUD
    def add_vet(self):
        name = self.vet_name_input.text().strip()
        phone = self.vet_phone_input.text().strip()
        email = self.vet_email_input.text().strip()
        specialty = self.vet_specialty_input.text().strip()

        if not name:
            print("Vet name is required.")
            return

        from clinic_oop import Vet
        new_vet = Vet(vet_name=name, vet_phone=phone, vet_email=email, specialty=specialty)
        self.db.create_vet(new_vet)
        self.load_vets()

    def edit_vet(self):
        selected_row = self.vet_table.currentRow()
        if selected_row == -1:
            print("Select a row to edit.")
            return

        vet_id = int(self.vet_table.item(selected_row, 0).text())
        name = self.vet_name_input.text().strip() or self.vet_table.item(selected_row, 1).text()
        phone = self.vet_phone_input.text().strip() or self.vet_table.item(selected_row, 2).text()
        email = self.vet_email_input.text().strip() or self.vet_table.item(selected_row, 3).text()
        specialty = self.vet_specialty_input.text().strip() or self.vet_table.item(selected_row, 4).text()

        from clinic_oop import Vet
        updated_vet = Vet(vet_id, name, phone, email, specialty)
        self.db.update_vet(updated_vet)
        self.load_vets()

    def delete_vet(self):
        selected_row = self.vet_table.currentRow()
        if selected_row == -1:
            print("Select a row to delete.")
            return

        vet_id = int(self.vet_table.item(selected_row, 0).text())
        self.db.delete_vet(vet_id)
        self.load_vets()

#APPOINTMENTS TAB UI -------------------------------------------------------------
    def init_appointments_tab(self):
        tab = QWidget()
        vbox = QVBoxLayout()
        tab.setLayout(vbox)

        #Appointments table
        self.appt_table = QTableWidget()
        vbox.addWidget(self.appt_table)
        #self.appt_table.setEditTriggers(QTableWidget.NoEditTriggers)

        #Input fields for [literally everything]
        form_layout = QHBoxLayout()
        self.appt_date_input = QLineEdit()
        self.appt_date_input.setPlaceholderText("YYYY/MM/DD HH:MM")
        self.appt_type_input = QLineEdit()
        self.appt_type_input.setPlaceholderText("Appointment Type")
        self.pet_type_input = QLineEdit()
        self.pet_type_input.setPlaceholderText("Pet Type")
        self.pet_name_input = QLineEdit()
        self.pet_name_input.setPlaceholderText("Pet Name")
        self.owner_name_input = QLineEdit()
        self.owner_name_input.setPlaceholderText("Owner Name")
        self.vet_name_input_appt = QLineEdit()
        self.vet_name_input_appt.setPlaceholderText("Vet Name")
        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText("Price")

        form_layout.addWidget(self.appt_date_input)
        form_layout.addWidget(self.appt_type_input)
        form_layout.addWidget(self.pet_type_input)
        form_layout.addWidget(self.pet_name_input)
        form_layout.addWidget(self.owner_name_input)
        form_layout.addWidget(self.vet_name_input_appt)
        form_layout.addWidget(self.price_input)
        vbox.addLayout(form_layout)

        #Buttons
        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.load_appointments)

        add_btn = QPushButton("Add Appointment")
        add_btn.clicked.connect(self.add_appointment)

        edit_btn = QPushButton("Edit Selected")
        edit_btn.clicked.connect(self.edit_appointment)

        delete_btn = QPushButton("Delete Selected")
        delete_btn.clicked.connect(self.delete_appointment)

        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(delete_btn)
        vbox.addLayout(btn_layout)

        #Appointments tab table
        self.tabs.addTab(tab, "Appointments")
        self.load_appointments()

    #Display
    def load_appointments(self):
        appts = self.db.read_appointment()
        self.appt_table.setRowCount(len(appts))
        self.appt_table.setColumnCount(13)
        self.appt_table.setHorizontalHeaderLabels(["ID", "Date/Time", "Type", "Pet", "Gender", "Name", "Breed",
                                                   "Age", "Weight", "Color", "Owner", "Vet", "Price"])
        for row_idx, appt in enumerate(appts):
            self.appt_table.setItem(row_idx, 0, QTableWidgetItem(str(appt.id)))
            self.appt_table.setItem(row_idx, 1, QTableWidgetItem(appt.appt))
            self.appt_table.setItem(row_idx, 2, QTableWidgetItem(appt.appt_type))
            self.appt_table.setItem(row_idx, 3, QTableWidgetItem(appt.pet_type or ""))
            self.appt_table.setItem(row_idx, 4, QTableWidgetItem(appt.gender or ""))
            self.appt_table.setItem(row_idx, 5, QTableWidgetItem(appt.name or ""))
            self.appt_table.setItem(row_idx, 6, QTableWidgetItem(appt.breed or ""))
            self.appt_table.setItem(row_idx, 7, QTableWidgetItem(str(appt.age_yrs) if appt.age_yrs else ""))
            self.appt_table.setItem(row_idx, 8, QTableWidgetItem(str(appt.weight_kgs) if appt.weight_kgs else ""))
            self.appt_table.setItem(row_idx, 9, QTableWidgetItem(appt.color or ""))
            self.appt_table.setItem(row_idx, 10, QTableWidgetItem(appt.owner if appt.owner else ""))
            self.appt_table.setItem(row_idx, 11, QTableWidgetItem(appt.vet if appt.vet else ""))
            self.appt_table.setItem(row_idx, 12, QTableWidgetItem(str(appt.price) if appt.price else ""))

    def add_appointment(self):
        appt = self.appt_date_input.text().strip()
        appt_type = self.appt_type_input.text().strip()
        pet_type = self.pet_type_input.text().strip()
        name = self.pet_name_input.text().strip()
        owner_name = self.owner_name_input.text().strip()
        vet_name = self.vet_name_input_appt.text().strip()
        price = self.price_input.text().strip()

        from clinic_oop import Appointment, Owner, Vet
        owner_obj = Owner(owner_name=owner_name)
        vet_obj = Vet(vet_name=vet_name)
        new_appt = Appointment(appt=appt, appt_type=appt_type, pet_type=pet_type,
                               name=name, owner=owner_obj, vet=vet_obj, price=float(price) if price else None)

        valid, msg = new_appt.validate()
        if not valid:
            print("Validation failed:", msg)
            return

        self.db.create_appointment(new_appt)
        self.load_appointments()

    def edit_appointment(self):
        selected_row = self.appt_table.currentRow()
        if selected_row == -1:
            print("Select a row to edit.")
            return

        appt_id = int(self.appt_table.item(selected_row, 0).text())
        appt = self.appt_date_input.text().strip() or self.appt_table.item(selected_row, 1).text()
        appt_type = self.appt_type_input.text().strip() or self.appt_table.item(selected_row, 2).text()
        name = self.pet_name_input.text().strip() or self.appt_table.item(selected_row, 3).text()
        owner_name = self.owner_name_input.text().strip() or self.appt_table.item(selected_row, 4).text()
        vet_name = self.vet_name_input_appt.text().strip() or self.appt_table.item(selected_row, 5).text()
        price = self.price_input.text().strip() or self.appt_table.item(selected_row, 6).text()

        from clinic_oop import Appointment, Owner, Vet
        owner_obj = Owner(owner_name=owner_name)
        vet_obj = Vet(vet_name=vet_name)
        updated_appt = Appointment(id=appt_id, appt=appt, appt_type=appt_type, name=name,
                                   owner=owner_obj, vet=vet_obj, price=float(price) if price else None)

        valid, msg = updated_appt.validate()
        if not valid:
            print("Validation failed:", msg)
            return

        self.db.update_appointment(updated_appt)
        self.load_appointments()

    def delete_appointment(self):
        selected_row = self.appt_table.currentRow()
        if selected_row == -1:
            print("Select a row to delete.")
            return

        appt_id = int(self.appt_table.item(selected_row, 0).text())
        self.db.delete_appointment(appt_id)
        self.load_appointments()